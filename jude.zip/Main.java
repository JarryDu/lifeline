package com.jude;

        import com.jude.prisoner.*;

        import java.util.Map;

public class Main {
    public static final Prisoner[] PRISONERS = {
            new BlakePrisonerM(),   // Reflect
            new HgsilPrisoner(),    // Reflect
            new JayPrisoner(),      // Reflect
            new NimaPrisoner(),
            new NookiaPrisoner(),   // Reflect
            new Rename(),           // Reflect
            new ZhangPrisoner(),
            new DxhPrisoner(),
                   };


public static void main(String[] args) {

        Manager manager = new Manager(PRISONERS,1000);

        manager.start(10000);
        for (Map.Entry<Prisoner, Integer> deciderIntegerEntry : manager.getScore().entrySet()) {
        System.out.println(deciderIntegerEntry.getKey().getName()+":"+deciderIntegerEntry.getValue());
        }
        }

        }
