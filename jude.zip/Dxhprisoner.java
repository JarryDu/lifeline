package com.jude.prisoner.;
import com.jude.Manager;
import com.jude.Prisoner;
interface Prisoner {

    void result(boolean survived);
}
public class Dxh implements Prisoner{
    public String getName(){
        return "dxh2016210505";

    }
    public void begin(Manager manager,int totalperson,int totalCount){

    }
    public int take(int index,int last){
        return Last;
    }
    public void result(boolean survived){

    }
}
